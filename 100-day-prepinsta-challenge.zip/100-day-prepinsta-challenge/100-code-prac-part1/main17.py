# power of number
base_num = int(input("Enter the base:\n"))
pow_num = int(input("Enter the expo:\n"))
print(pow(base_num,pow_num))

