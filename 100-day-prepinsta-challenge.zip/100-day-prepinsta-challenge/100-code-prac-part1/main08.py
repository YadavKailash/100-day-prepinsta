# prime in range
import math
beg = int(input("Enter the range beg:\n"))
end = int(input("Enter the range end:\n"))

def isPrime(num):
    for i in range(2,int((math.sqrt(num))) + 1):
        if num % i == 0:
            return False
    return True

for i in range(beg,end + 1):
    if isPrime(i):
        print(i,end=" ")
