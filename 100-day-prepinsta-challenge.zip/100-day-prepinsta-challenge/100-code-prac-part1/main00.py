n = input("Enter non-zero number:\n")
n = int(n)
print("positive" if n > 0 else "negative")