# harshad aka num div by it`s digits sum , ex 27
num = int(input("Enter the num:\n"))
res , temp = 0, num
while temp:
    res += temp%10
    temp //= 10
print("Harshad" if num%res == 0 else "Not Harshad")
