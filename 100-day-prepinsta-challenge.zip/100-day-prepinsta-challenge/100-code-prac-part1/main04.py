# greatest of 2 number
num1 = int(input("Enter first num:\n"))
num2 = int(input("Enter second num:\n"))
print(num1 if num1 > num2 else num2)