# reverse the number
num = int(input("Enter the number:\n"))
res = 0
while num:
    res = res*10 + num%10
    num //= 10
print(res)