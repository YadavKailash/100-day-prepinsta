# palindromic number
num = int(input("Enter the number:\n"))
rev_num, temp = 0, num
while temp:
    rev_num = rev_num*10 + temp%10
    temp //= 10
print("Palindrome" if num == rev_num else "Not Palindrome")
