# sum of 1st n natuaral languages
num = int(input("Enter the number:\n"))
print(num*(num + 1)//2)