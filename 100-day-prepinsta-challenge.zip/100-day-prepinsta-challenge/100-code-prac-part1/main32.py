# hex to dec
num = input("Enter the hex digits:\n")
num = num.upper()
res , hex_alpha = 0 , 'ABCDEF'
for dig in num:
    res = res*16 + (int(dig) if dig.isdigit() else 10 + hex_alpha.index(dig))
print(res)