# Count possible decoding of a given digit sequence :
# 121 => 2 why (12)(1), (1)(2)(1)

num = input("Enter the num:\n")
def cnt_decode(num,i):
    if i == len(num):
        return 1
    if num[i] == "0":
        return 0
    res = cnt_decode(num,i+1)
    if (i + 1 < len(num) and (num[i] == "1"
        or num[i] == "2" and num[i+1] in "0123456")):
        res += cnt_decode(num,i + 2)
    return res

print(cnt_decode(num,0))