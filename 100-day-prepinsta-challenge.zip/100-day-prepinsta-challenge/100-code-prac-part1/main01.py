num = int(input("Enter the number:\n"))
print("Even" if num%2 == 0 else "Odd")