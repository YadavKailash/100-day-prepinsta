# hcf by bcab method
a,b = map(int,list(input().split()))
def hcf(a,b):
    return a if b == 0 else hcf(b,a%b)
print(f'HCF of {a} and {b}: {hcf(a,b)}')