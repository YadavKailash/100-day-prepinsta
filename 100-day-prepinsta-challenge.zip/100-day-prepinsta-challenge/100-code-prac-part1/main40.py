# max no of handshakes = n*(n - 1)//2
num = int(input("Enter the num:\n"))
print(f"Max no of handshakes: {num*(num - 1)//2}")
