# Convert digit/number to words support upto 4 digits num
# 1111: one thousand one hundred eleven
to_words = ["","one","two","three","four","five","six","seven","eight","nine","ten",
            "","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen",
            "eighteen","ninteen","twenty","thirty","forty","fifty","sixty","seventy",
            "eighty","ninety","hundreds","thousands"]
num = input("Enter the num:\n")
res, tot_dig = "", len(num)
for i,dig in enumerate(num):
    if tot_dig - i == 4:
        res = res + to_words[int(dig)] + " " + to_words[-1] + " "
    elif tot_dig - i == 3:
        res = res + to_words[int(dig)] + " " + to_words[-2] + " "
    elif tot_dig - i == 2:
        res = res + to_words[int(dig) + 12] + " " + 
