# automorphic aka sq end with num itself
num = int(input("Enter the number:\n"))
sq_num = num * num
print("Automorphic" if str(sq_num).endswith(str(num)) else "Not Automorphic")