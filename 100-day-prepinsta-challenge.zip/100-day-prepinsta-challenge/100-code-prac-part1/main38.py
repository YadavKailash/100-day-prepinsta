# determine the quadrant
x_cor,y_cor = map(int,list(input().split()))

if x_cor == y_cor == 0:
    print(f"{x_cor} {y_cor} lies on origin")
elif x_cor == 0:
    print(f"{x_cor} {y_cor} lies on y-axis")
elif y_cor == 0:
    print(f"{x_cor} {y_cor} lies on x-axis")
elif min(x_cor,y_cor) > 0:
    print(f"{x_cor} {y_cor} lies in 1st quadrant")
elif max(x_cor,y_cor) < 0:
    print(f"{x_cor} {y_cor} lies in 3rd quadrant")
elif x_cor > 0 and y_cor < 0:
    print(f"{x_cor} {y_cor} lies in 2nd quadrant")
else:
    print(f"{x_cor} {y_cor} lies in 4th quadrant")