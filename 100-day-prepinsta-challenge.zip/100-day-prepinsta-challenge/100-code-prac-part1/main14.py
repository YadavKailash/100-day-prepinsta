# fib upto n term
num = int(input("Enter the no of term:\n"))
res = [0,1]
for i in range(num - 2):
    res.append(res[-1] + res[-2])
print(*res)



