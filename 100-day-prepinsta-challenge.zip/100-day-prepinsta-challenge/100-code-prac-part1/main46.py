# Find the prime numbers between 1 to 100
all_primes = [True]*(101)
all_primes[0] = all_primes[1] = False

for i in range(2,11):
    if all_primes[i]:
        for j in range(i*i,101,i):
            all_primes[j] = False

for i,primes in enumerate(all_primes):
    if primes:
        print(i,end=" ")
