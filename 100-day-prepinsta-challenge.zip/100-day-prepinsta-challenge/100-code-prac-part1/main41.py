# addition of 2 fraction : n1/d1 + n2/d2 = (n1*d2 + n2*d1)/(d1*d2)
n1,d1 = map(int,list(input("Enter numerator and denominator of first number:\n").split()))
n2,d2 = map(int,list(input("Enter numerator and denominator of second number:\n").split()))
def hcf(a,b):
    return a if b==0 else hcf(b,a%b)
comm_fact = hcf(n1*d2 + n2*d1,d1*d2)
print(f'{n1}/{d1} + {n2}/{d2} = {(n1*d2 + n2*d1)//comm_fact}/{d1*d2//comm_fact}')
