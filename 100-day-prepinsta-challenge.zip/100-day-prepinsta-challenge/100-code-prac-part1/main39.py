# Permutations in which n people can occupy r seats in a classroom
# nPr = n!/(n - r)!

def fact(num):
    return 1 if num == 0 or num == 1 else num*fact(num - 1)

n,r = map(int,list(input().split()))
print(f'nPr : {fact(n)//fact(n - r)}')

