# Counting number of days in a given month of a year
# month,year => 28/29/30/31

month_days = [0,31,28,31,30,31,30,31,31,30,31,30,31]
month,year = map(int,list(input().split()))

def is_leap_year(yr):
    if yr % 4 == 0 and yr % 100 != 0:
        return 1
    elif yr % 400 == 0:
        return 1
    else:
        return 0

print(f'Number of days = {month_days[month] + (1 if month == 2 and is_leap_year(year) else 0)}')