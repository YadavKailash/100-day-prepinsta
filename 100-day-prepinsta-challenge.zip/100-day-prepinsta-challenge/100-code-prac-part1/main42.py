# convert all 0 to 1 in num
num = input("Enter the num:\n")
res = 0
for dig in num:
    res = res*10 + max(1,int(dig))
print(res)