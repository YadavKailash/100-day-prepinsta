# armstrong in given range
beg, end = map(int,list(input("Enter range in single line: ").split()))

def is_armstrong(num):
    temp, cnt_digs, res = num , len(str(num)), 0
    while temp:
        res = res + pow(temp%10,cnt_digs)
        temp //= 10
    return res == num

for num in range(beg,end + 1):
    if is_armstrong(num):
        print(num,end=" ")
