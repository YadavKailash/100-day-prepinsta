# factorial of num
num = int(input("Enter the num:\n"))
res = 1
for i in range(1,num + 1):
    res *= i
print(res)