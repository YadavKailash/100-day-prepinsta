# leap or not
year = int(input("Enter the year you want to check:\n"))
if year%400 == 0 or (year%4 == 0 and year % 100!=0):
    print("It is leap year")
else:
    print("It is not leap year")

    