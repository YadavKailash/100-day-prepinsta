# factor of number
num = int(input("Enter the num:\n"))
print("Factors of number are:")
for i in range(1,num + 1):
    if num % i == 0:
        print(i,end=" ")
