# dec to bin
num = int(input("Enter the num:\n"))
print(bin(num))