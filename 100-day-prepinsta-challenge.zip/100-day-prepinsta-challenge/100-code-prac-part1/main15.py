# nth fibo number
num = int(input("Enter the number:\n"))
res = [0,1]
for i in range(num - 2):
    res.append(res[-1] + res[-2])
print(res[-1],": Nth fibo number")