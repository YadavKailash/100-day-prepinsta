# perfect square
from math import ceil,floor,sqrt
num = int(input("Enter the num:\n"))
print("Perfect square" if ceil(sqrt(num)) == floor(sqrt(num)) else "Not Perfect Square")