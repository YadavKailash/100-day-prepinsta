# sum of number in given range aka beg , end
beg = int(input("Enter the range beg:\n"))
end = int(input("Enter the range end:\n"))
beg = beg - 1
before_beg = beg*(beg + 1)//2
before_end = end*(end + 1)//2
print(before_end - before_beg)

