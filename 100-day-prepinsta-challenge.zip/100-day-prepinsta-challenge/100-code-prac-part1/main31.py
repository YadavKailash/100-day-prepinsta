# oct to dec :  653 => 427
num = input("Enter the oct digits:\n")
res = 0
for dig in num:
    res = res*8 + int(dig)
print(res)