# sum of digit of number
num = int(input("Enter the number:\n"))
res , temp = 0 , num
while temp:
    res = res + (temp % 10)
    temp //= 10
print(f"Sum of digit: {res}")


