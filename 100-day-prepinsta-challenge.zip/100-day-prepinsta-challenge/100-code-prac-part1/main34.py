# dec to oct
num = int(input("Enter the num:\n"))
print(oct(num))