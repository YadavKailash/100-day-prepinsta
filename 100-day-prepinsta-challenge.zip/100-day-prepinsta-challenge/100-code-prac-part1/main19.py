# prime factor of number
import math
num = int(input("Enter the number:\n"))
all_primes = [True]*(num + 1)
for i in range(2,int(math.sqrt(num)) + 1):
    if all_primes[i]:
        for j in range(i*i,num + 1,i):
            all_primes[j] = False

i = 2
while num > 1:
    if all_primes[i] and num % i == 0:
        print(i,end=" ")
        num //= i
    else:
        i = i + 1
