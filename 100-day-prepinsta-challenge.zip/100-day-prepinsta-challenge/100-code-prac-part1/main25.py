# abundant num aka sum of proper fact > num ex : 12
num = int(input("Enter the num:\n"))
res = 0
for i in range(1,num//2 + 1):
    if num % i == 0:
        res += i
if res > num:
    print(f'{num} is adundant number')
    print(f'The abundance is {res - num}')
else:
    print("It is not abundance number")