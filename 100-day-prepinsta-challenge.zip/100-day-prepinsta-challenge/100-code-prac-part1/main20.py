# strong number aka sum of fact == num ex 145
num = int(input("Enter the number:\n"))
def fact(num):
    return 1 if num == 0 or num == 1 else num * fact(num - 1)

all_fact = [fact(i) for i in range(10)]
res , temp = 0 , num
while temp:
    res = res + all_fact[temp%10]
    temp //= 10
print("Strong" if res == num else "Not Strong")