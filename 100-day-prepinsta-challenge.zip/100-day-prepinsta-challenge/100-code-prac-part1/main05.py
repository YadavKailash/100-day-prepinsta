# greatest of three num
num1,num2,num3=map(int,list(input().split()))
print("Greatest among these three:\n")
if num1 > num2:
    print(num1 if num1 > num3 else num3)
else:
    print(num2 if num2 > num3 else num3)