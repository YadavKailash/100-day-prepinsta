# oct to bin

oct_num = input("Enter the oct num:\n")
def oct_to_dec(num):
    res = 0
    for dig in num:
        res = res*8 + int(dig)
    print(f'Decimal: {res}')
    return res

def dec_to_bin(num):
    bin_num = bin(num)
    print(f'Binary: {str(bin_num)[2:]}')

dec_to_bin(oct_to_dec(oct_num))