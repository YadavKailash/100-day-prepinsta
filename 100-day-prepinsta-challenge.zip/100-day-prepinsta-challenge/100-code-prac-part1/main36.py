# bin to oct
bin_num = input()
def bin_to_dec(num):
    res = 0
    for dig in num:
        res = res*2 + int(dig)
    print(f'Decimal: {res}')
    return res
def dec_to_oct(num):
    oct_num = oct(num)
    print(f'Oct : {str(oct_num)[2:]}')

dec_to_oct(bin_to_dec(bin_num))