# Calculate the number of digits in an integer
num,dig = list(input("Enter num and dig:\n").split())
res = 0
for ch in num:
    if ch == dig:
        res += 1
print(res)
