# Can a number be expressed as a sum of two prime numbers
from math import sqrt
num = int(input("Enter the num:\n"))
all_primes = [True]*(num + 1)
all_primes[0] = all_primes[1] = False
for i in range(2,int(sqrt(num))+ 1):
    if all_primes[i]:
        for j in range(i*i,num + 1,i):
            all_primes[j] = False
primes = []
for i,prime in enumerate(all_primes):
    if prime:
        primes.append(i)
print(primes)
beg , end , res = 0, len(primes) - 1, -1
while beg < end:
    if primes[beg] + primes[end] == num:
        print(f'{num} can be expressed as sum of {primes[beg]} and {primes[end]}')
        res = num
        break
    elif primes[beg] + primes[end] < num:
        beg += 1
    else:
        end -= 1

if res == -1:
    print("Cann`t be expressed!!")