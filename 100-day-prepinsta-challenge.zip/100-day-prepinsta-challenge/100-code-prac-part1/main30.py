# bin to dec
num = input("Enter the bin digits:\n")
res = 0
for dig in num:
    res = res*2 + int(dig)
print(res)