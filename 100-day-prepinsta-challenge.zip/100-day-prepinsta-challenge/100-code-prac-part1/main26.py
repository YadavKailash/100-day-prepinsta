# friendly pairs aka proper divisor sum to number ratio are equal ex: 6 , 28
num1,num2 = map(int,list(input().split()))
def get_proper_div_sum(num):
    res = 0
    for i in range(1,num//2 + 1):
        if num % i == 0:
            res += i
    return res

if get_proper_div_sum(num1)/num1 == get_proper_div_sum(num2)/num2:
    print(f'{num1} and {num2} are Friendly Pairs')
else:
    print(f'{num1} and {num2} are not Friendly Pairs')

