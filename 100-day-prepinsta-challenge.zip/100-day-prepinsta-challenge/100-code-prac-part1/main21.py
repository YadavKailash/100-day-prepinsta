# perfect num aka sum of proper fact == num
num = int(input("Enter the number:\n"))
res = 0 
for i in range(1,num//2 + 1):
    if num % i == 0:
        res = res + i
print("Perfect" if res == num else "Not Perfect")