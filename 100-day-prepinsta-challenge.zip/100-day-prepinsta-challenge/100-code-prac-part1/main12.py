# armstrong number aka sum(dig*cnt_digits) == number
# 137 not armstrong , 371 armstrong
num = int(input("Enter the number:\n"))
temp, cnt_digs, res = num , len(str(num)), 0
while temp:
    res = res + pow(temp%10,cnt_digs)
    temp //= 10
print("Armstrong" if num == res else "Not Armstrong")
