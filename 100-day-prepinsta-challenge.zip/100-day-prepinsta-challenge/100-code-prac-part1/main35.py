# dec to hex
num = int(input("Enter the num:\n"))
print(hex(num))