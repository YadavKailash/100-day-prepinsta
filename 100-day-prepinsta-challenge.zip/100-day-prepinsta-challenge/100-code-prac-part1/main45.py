# area of circle
from math import pi
r = int(input("Enter the radius:\n"))
print(pi*r*r)