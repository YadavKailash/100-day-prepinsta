# Juggling algorithm for array rotation
