# Sort the elements of an array

arr = [int(x) for x in input().split()]
def selection_sort(beg,end):
    for i in range(beg,end + 1):
        for j in range(i+1,end + 1):
            if arr[i] > arr[j]:
                arr[i],arr[j] = arr[j],arr[i]

print(f'Array element before sorting:')
print(arr)
selection_sort(0,len(arr) - 1)
print(f'Array element after sorting:')
print(arr)