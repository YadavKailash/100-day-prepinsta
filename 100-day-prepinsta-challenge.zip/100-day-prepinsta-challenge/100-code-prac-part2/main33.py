# Counting Distinct Elements in an Array 
arr = [int(x) for x in input().split()]
seen , count = set(), 0

for ele in arr:
    if ele not in seen:
        count += 1
        seen.add(ele)
print(f'Total distinct element: {count}')