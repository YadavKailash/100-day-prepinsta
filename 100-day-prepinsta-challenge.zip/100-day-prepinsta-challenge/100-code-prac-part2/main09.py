# lcm of 2 number using recursion
# prod of number = lcm * hcf

num1,num2 = map(int,list(input().split()))

def gcd(n1,n2):
    return n1 if n2 == 0 else gcd(n2,n1%n2)

def lcm(n1,n2):
    return n1*n2//gcd(n1,n2)

print(f'LCM of {num1} & {num2}: {lcm(num1,num2)}')
