# Finding Minimum scalar product of two vectors

vector1 = [int(x) for x in input().split()]
vector2 = [int(x) for x in input().split()]

vector1.sort()
vector2.sort(reverse=True)

res = 0
for val1,val2 in zip(vector1,vector2):
    res = res + val1*val2

print(res)