# largest element in arr

arr = [int(x) for x in input().split()]
print(f'Max element: {max(arr)}')