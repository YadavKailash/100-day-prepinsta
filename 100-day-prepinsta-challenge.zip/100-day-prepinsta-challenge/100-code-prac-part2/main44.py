# Determine can all numbers of an array be made equal by multiply with 2 or 3
# [50,75,100] => "YES"

arr = [int(x) for x in input().split()]

def simplify_me(num):
    while num % 2 == 0:
        num = num // 2
    while num % 3 == 0:
        num = num // 3
    return num

first_num = simplify_me(arr[0])
is_possible = True
for ele in arr:
    if simplify_me(ele) != first_num:
        is_possible = False
        break
if is_possible:
    print("All numbers of an array be made equal.")
else:
    print("All numbers of an array cannot be made equal.")
