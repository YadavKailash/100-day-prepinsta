#program to calculate length of the string using recursion

s = input("Enter a string:\n")

def len_str(s):
    if s == "":
        return 0
    return 1 + len_str(s[1:])

print(f'Length of string: {len_str(s)}')