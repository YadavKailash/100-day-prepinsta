# Finding the Longest Palindromic number  in an Array 
# 1 232 121 233 23 22 => 232
arr = [int(x) for x in input().split()]
res = -float('inf')
def is_palindrome(num):
    return str(num) == str(num)[::-1]

for ele in arr:
    if ele > res and is_palindrome(ele):
        res = ele
print(res)