# find second smallest element in arr

arr = [int(x) for x in input().split()]
min_val1,min_val2 = float('inf'),float('inf')

for ele in arr:
    if ele < min_val1:
        min_val2 = min_val1
        min_val1 = ele
    elif ele < min_val2 and ele != min_val1:
        min_val2 = ele

print(f'2nd smallest element: {min_val2}')
