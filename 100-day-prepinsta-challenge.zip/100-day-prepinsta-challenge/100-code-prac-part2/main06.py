#smallest element in an array using recursion
#empty arr: -1 else smallest element

arr = list(input().split())
arr = [int(x) for x in arr]

def find_min(ind):
    if ind == len(arr) - 1:
        return arr[-1]
    return min(arr[ind],find_min(ind + 1))

print(f'Min number in the arr: {find_min(0) if arr else -1}')
