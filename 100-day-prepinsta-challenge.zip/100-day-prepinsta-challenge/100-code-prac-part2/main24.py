# largest and smallest val in arr

arr = [int(x) for x in input().split()]

min_val,max_val = float('inf'),-float('inf')
for ele in arr:
    if min_val > ele:
        min_val = ele
    if max_val < ele:
        max_val = ele

print(f'Min and Max value: {min_val} & {max_val}')