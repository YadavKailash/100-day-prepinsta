# finding repeating element in arr
from collections import Counter
arr = [int(x) for x in input().split()]
counter = Counter(arr)
print(f'Repeating element in the arr:')
if not counter:
    print("All element are distinct: ")
for ele,freq in counter.items():
    if freq > 1:
        print(ele,end=" ")
