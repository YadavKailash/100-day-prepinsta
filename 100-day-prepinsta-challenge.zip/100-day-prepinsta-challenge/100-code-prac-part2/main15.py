# Given a positive integer N, return the Nth row of pascal’s triangle
# 1 \n 1 1 \n 1 2 1 \n 1 3 3 1 \n......... respectively for 1, 2, 3..

num = int(input("Enter the num:\n"))
all_rows = [[1]]

def get_nth_row(curr):
    if curr == num:
        return 
    curr_rows = [1]*(len(all_rows[-1]) + 1)
    for i in range(1,len(curr_rows)-1):
        curr_rows[i] = all_rows[-1][i-1] + all_rows[-1][i]
    all_rows.append(curr_rows)
    del curr_rows
    get_nth_row(curr + 1)

get_nth_row(0)
print(f'Nth row in the pascal triangle: {all_rows[num]}')