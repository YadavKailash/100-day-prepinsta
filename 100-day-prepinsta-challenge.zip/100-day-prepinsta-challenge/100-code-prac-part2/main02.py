# Finding Roots of a quadratic equation
# ax^2 + bx + c = 0 : (-b±sqrt(disc))/2a
# (a,b,c)=>roots: disc +0- for real distinct,real repeated,imaginary roots

from math import sqrt
a,b,c = map(int,list(input().split()))

def find_roots(a,b,c):
    disc = b*b - 4*a*c
    if disc > 0:
        print("Root of quadratic equation are real and distinct")
        print(f'First root: {(-b+sqrt(disc))/2*a}')
        print(f'Second root: {(-b-sqrt(disc))/2*a}')
    elif disc == 0:
        print(f'Root of quadratic equation are real and repeated:')
        print(f"Root: {-b/2*a}")
    else:
        print(f'Root of quadratic equation are imaginary')
        print(f'First Root: {-b/2*a} + {sqrt(-disc)/2*a}i')
        print(f'Second Root: {-b/2*a} - {sqrt(-disc)/2*a}i')

find_roots(a,b,c)
