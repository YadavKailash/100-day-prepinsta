# reverse the array

arr = [int(x) for x in input().split()]
print(f'Array before reversal:')
print(*arr)
beg,end = 0,len(arr) - 1
while beg < end:
    arr[beg],arr[end] = arr[end],arr[beg]
    beg, end = beg + 1, end - 1
print(f'Array after reversal:')
print(*arr)