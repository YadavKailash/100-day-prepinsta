# sum of element of an array

arr = [int(x) for x in input().split()]
curr_sum = 0

for ele in arr:
    curr_sum += ele

print(f'Sum of array ele: {curr_sum}')