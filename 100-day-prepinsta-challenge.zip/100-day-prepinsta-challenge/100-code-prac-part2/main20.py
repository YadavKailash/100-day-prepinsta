# Given a set of positive integers, find all its subsets 
# [1,2] => [{},{1},{1,2},{2}]


arr = [int(x) for x in list(input().split())]
res = []

def dfs(curr_list,ind):
    if ind == len(arr):
        res.append(curr_list[:])
        return
    # include 
    curr_list.append(arr[ind])
    dfs(curr_list,ind + 1)
    # exclude
    curr_list.pop()
    dfs(curr_list,ind + 1)

print(f'All Subsets: ')
dfs([],0)
print(res)
    