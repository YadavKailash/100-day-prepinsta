# Finding symmetric pairs in an array in Python
# [(3, 4), (1, 2), (5, 2), (7, 10), (4, 3), (2, 5)] => [(3,4),(2,5)]

arr = [(3, 4), (1, 2), (5, 2), (7, 10), (4, 3), (2, 5)]

def print_pair(arr):
    seen = set()
    for (x,y) in arr:
        seen.add((x,y))
        if (y,x) in seen:
            print((x,y) if x < y else (y,x))

print_pair(arr)