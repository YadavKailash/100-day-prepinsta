# Counting the number of even and odd elements in an array
arr = [int(x) for x in input().split()]
even_cnt, odd_cnt = 0,0
for ele in arr:
    if ele % 2 == 0:
        even_cnt += 1
    else:
        odd_cnt += 1

print(f'Even count: {even_cnt}')
print(f'Odd count: {odd_cnt}')
