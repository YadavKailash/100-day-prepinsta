# Rotation of elements of array by one position - left and right
# Left-Rotation: [1,2,3,4,5] => [2,3,4,5,1]
# Right-Rotation: [1,2,3,4,5] => [5,1,2,3,4]

arr = [int(x) for x in input().split()]

print(f'Left-Rotation: ')
print(arr[1:] + [arr[0]])
print(f'Right-Rotation: ')
print([arr[-1]] + arr[:-1])
