# Finding the frequency of elements in an array

arr = [int(x) for x in input().split()]
freq_map = {}

for ele in arr:
    freq_map[ele] = freq_map.get(ele,0) + 1

for num,freq in freq_map.items():
    print(f'{num} : {freq}')