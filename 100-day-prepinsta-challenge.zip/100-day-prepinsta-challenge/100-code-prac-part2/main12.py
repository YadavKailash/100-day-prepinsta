# Given an integer N the task is to print the F(N)th term using recursion
# f(4) = (1) + (2*3) + (4*5*6) + (7*8*9*10) 
# things to note: start = (i-1)*i//2 + 1, #ofTerm = i

num = int(input("Enter the no of term:\n"))
def func(curr):
    if curr < 2:
       return curr
    curr_term_val, start = 1 , (curr - 1)*curr//2 + 1
    for i in range(start,start + curr):
        curr_term_val *= i 
    return curr_term_val + func(curr - 1)
print(f'F(Nth) term = {func(num)}')
