# Sort an array according to the order defined by another array
# sort arr1 according to the element of arr2

arr1 = [int(x) for x in input().split()]
arr2 = [int(x) for x in input().split()]

