# Finding number of integers which has exactly x divisors from 1 to n:

num , x = map(int,list(input().split()))
res = 0
for i in range(1, num + 1):
    factor_so_far = 0
    for j in range(1,i + 1):
        if i % j == 0:
            factor_so_far += 1
    if factor_so_far == x:
        res += 1
print(f'No of integer with exactly x divisors: {res}')