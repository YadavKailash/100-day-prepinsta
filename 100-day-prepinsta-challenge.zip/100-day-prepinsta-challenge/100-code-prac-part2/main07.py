# reversing a number using recursion
# how we establish faith in recursion
num = input("Enter the num:\n")
num = list(num)

def rev_num(ind):
    if ind == len(num) - 1:
        return num[-1]
    return rev_num(ind + 1) + num[ind]

print(f'Reversed number: {rev_num(0)}')