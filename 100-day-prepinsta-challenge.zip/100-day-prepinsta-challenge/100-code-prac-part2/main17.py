# Find the Factorial of a number using recursion
num = int(input("Enter the num:\n"))
def fact(n):
    if n < 2:
        return 1
    return n * fact(n - 1)
print(f'Factorial of {num}:  {fact(num)}')