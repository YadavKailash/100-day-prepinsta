# hcf of two number using recursion
num1,num2 = map(int,list(input().split()))

def gcd(a,b):
    return a if b == 0 else gcd(b,a%b)

print(f'HCF of {num1} & {num2}: {gcd(num1,num2)}')

