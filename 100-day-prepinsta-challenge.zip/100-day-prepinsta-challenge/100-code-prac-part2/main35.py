# non-repeating element in arr
from collections import Counter
arr = [int(x) for x in input().split()]
counter = Counter(arr)
if not counter:
    print("No element are distinct!")

for ele,freq in counter.items():
    if freq == 1:
        print(ele,end=" ")
