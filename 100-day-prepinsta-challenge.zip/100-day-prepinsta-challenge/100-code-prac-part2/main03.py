# Power of a Number using recursion
# base,expo => res : assume domain of base and expo is whole num

def power_using_rec(base,expo):
    if expo == 0:
        return 1
    if expo == 1:
        return base
    return base * power_using_rec(base,expo - 1)

base,expo = map(int,list(input().split()))
print(power_using_rec(base,expo))

    