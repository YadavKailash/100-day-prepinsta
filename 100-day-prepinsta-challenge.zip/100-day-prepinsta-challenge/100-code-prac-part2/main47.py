'''
Replace each element of the array by its rank in the array
Rank of an element is defined as the distance between the
element with the first element of the array when the array
is arranged in ascending order.
Ex: [100,2,70,12,90]=>[5,1,3,2,4]
'''

arr = [int(x) for x in input().split()]
aux = arr[:]
aux.sort()
val2ind = {val:ind for ind,val in enumerate(aux)}

for i,val in enumerate(arr):
    print(val2ind[val] + 1,end=" ")

