# Finding Number of times x digit occurs in a given input
# (897982,9) => 2
num,dig = list(input("Enter num & dig:\n").split())
res = 0
for ch in num:
    if dig == ch:
        res += 1
print(f'Number of Occurence of digit {dig} in {num}: {res}')
