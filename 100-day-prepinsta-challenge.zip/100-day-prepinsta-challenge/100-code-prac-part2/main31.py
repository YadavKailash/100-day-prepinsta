# Sorting elements of an array by frequency, such that higher freq element comes first.
# 20 30 20 10 20 30 10 20 20 
from collections import Counter

arr = [int(x) for x in input().split()]
counter = Counter(arr)
arr_freq = [[ele,freq] for ele,freq in counter.items()]
# sort on the basis of 2val aka freq
arr_freq.sort(key=lambda x:-x[1])
for ele,freq in arr_freq:
    print(ele, end=" ")