"""
Given an integer N representing the number of pairs of parentheses,
the task is to generate all combinations of well-formed(balanced) parentheses 
Ex: n = 2 => {{}}, {}{}
"""

num = int(input("Enter the num:\n"))
res = []

def dfs():

    