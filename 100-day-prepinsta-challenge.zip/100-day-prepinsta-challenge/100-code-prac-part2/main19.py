# Find all the N-bit binary numbers having more than or equal 1’s than 0’s
# 4 => [1111, 1110, 1101, 1100, 1011, 1010]


num = int(input("Enter the num:\n"))
def more_or_equal_ones(num):
    ones_cnt, zeros_cnt = 0 , 0
    while num:
        rem = num%2
        if rem:
            ones_cnt += 1
        else:
            zeros_cnt += 1
        num //= 2
    return ones_cnt >= zeros_cnt

beg, end, res = 2**(num - 1), 2**(num), []
for i in range(beg,end):
    if more_or_equal_ones(i):
        res.append(str(bin(i))[2:])
print(*res)