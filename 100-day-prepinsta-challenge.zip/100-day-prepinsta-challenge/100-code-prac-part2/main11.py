# Print All Permutations of a String using Recursion.
# dfs(...how many var...&...why) : dry run for "ABC"

s = input("Enter the string:\n")
s , res = list(s), []

def dfs(beg,end):
    if beg == end:
        res.append("".join(s[:]))
    for i in range(beg,end + 1):
        s[i],s[beg] = s[beg],s[i]
        dfs(beg + 1,end)
        s[i],s[beg] = s[beg],s[i]

dfs(0,len(s) - 1)
print(f'All permutation of string: {"".join(s)}\n{res}')