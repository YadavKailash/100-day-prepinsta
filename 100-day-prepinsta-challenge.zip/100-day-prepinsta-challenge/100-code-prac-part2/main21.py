# Given a string s, remove all its adjacent duplicate characters recursively
# Ex: aabaabccded => e

s = input("Enter the string:\n")

def dfs(s):
    if len(s) < 2:
        return s
    return dfs(s[1:]) if s[0] == s[1] else s[0] + dfs(s[1:])

print(f'String after removal of adj duplicate char: {dfs(s)}')