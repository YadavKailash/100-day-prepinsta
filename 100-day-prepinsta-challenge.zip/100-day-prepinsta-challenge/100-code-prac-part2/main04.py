#check prime number using recursion

num = int(input("Enter any number:\n"))

def is_prime(numb,ind):
    if numb < ind*ind:
        return True
    if numb % ind == 0:
        return False
    return is_prime(numb,ind + 1)

print("YES" if is_prime(num,2) else "NO")
    
