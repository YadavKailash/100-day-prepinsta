# Given a list arr of N integers, print sums of all subsets in it.
# {3,4,5} => 12, 7, 8, 3, 9, 4, 5, 0

arr = [int(x) for x in list(input().split())]
res = []
def subset_sum(curr_list,curr):
    if curr == len(arr):
        res.append(0 if not curr_list[:] else sum(curr_list[:]))
        return
    # include the element in curr_list
    curr_list.append(arr[curr])
    subset_sum(curr_list,curr + 1)
    # not include the element in curr_list
    curr_list.pop()
    subset_sum(curr_list,curr + 1)

subset_sum([],0)
print(f'Sum of all subset:\n{res}')