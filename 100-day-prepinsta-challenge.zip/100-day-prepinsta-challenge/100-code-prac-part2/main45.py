# Finding minimum sum of absolute difference of given array.
