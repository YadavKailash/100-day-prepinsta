# smallest element in arr

arr = [int(x) for x in input().split()]
print(f'Smallest element: {min(arr)}')