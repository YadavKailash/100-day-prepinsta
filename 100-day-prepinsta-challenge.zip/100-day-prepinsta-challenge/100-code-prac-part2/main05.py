# Largest element in an array using recursion
# array arr: -1 else largest number

arr = list(input().split())
arr = [int(x) for x in arr]

def find_max(ind):
    if ind == len(arr) - 1:
        return arr[-1]
    return max(arr[ind],find_max(ind+1))

print(f'Max element in arr: {find_max(0) if arr else -1}')