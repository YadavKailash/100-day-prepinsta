# Last non-zero digit in factorial

num = int(input("Enter the num:\n"))
def fact(n):
    if n < 2:
        return 1
    return n*fact(n - 1)

def last_non_zero_digit(num):
    if num % 10:
        return num%10
    return last_non_zero_digit(num//10)

print(f'Last Non-Zero Digit in factorial: {last_non_zero_digit(fact(num))}')