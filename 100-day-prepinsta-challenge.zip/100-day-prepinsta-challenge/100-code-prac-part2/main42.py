# Finding Arrays are disjoint or not 

arr1 = [int(x) for x in input().split()]
arr2 = [int(x) for x in input().split()]

seen1, is_disjoint = set(arr1), True
for ele in arr2:
    if ele in seen1:
        is_disjoint = False
        break
print(f'Disjoint: {"YES" if is_disjoint else "NO"}')
