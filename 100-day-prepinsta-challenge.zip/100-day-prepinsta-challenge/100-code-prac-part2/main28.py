# Sort first half in ascending order and second half in descending 
# sort all and then reverse from mid 
arr = [int(x) for x in input().split()]

def reverse(beg,end):
    while beg < end:
        arr[beg],arr[end] = arr[end],arr[beg]
        beg, end = beg + 1, end - 1
    
def asc_sort(beg,end):
    for i in range(beg,end + 1):
        for j in range(i+1,end + 1):
            if arr[i] > arr[j]:
                arr[i],arr[j] = arr[j],arr[i]
    
def desc_sort(beg,end):
    asc_sort(beg,end)
    reverse(beg,end)

print('Array after sorting as needed: ')
mid = len(arr)//2
asc_sort(0,mid)
desc_sort(mid+1,len(arr)-1)
print(arr)