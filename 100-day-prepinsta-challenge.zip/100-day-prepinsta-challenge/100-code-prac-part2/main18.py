# Find all possible palindromic partitions of the given String.
# "nitin" => {n i t i n,n iti n,nitin}
# even/odd len palindrome partitioning

s = input("Enter the string:\n")

for i in range(len(s)):
    prev,next = i,i+1
    while s[prev]
