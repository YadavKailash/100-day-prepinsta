# Determine Array is a subset of another array or not 
# [11, 12, 13, 21, 30, 70] & [11, 30, 70, 12] => "YES"

arr1 = [int(x) for x in input().split()]
arr2 = [int(x) for x in input().split()]

seen1,seen2 = set(arr1), set(arr2)

is_subset1, is_subset2 = True, True
for ele in seen1:
    if ele not in seen2:
        is_subset1 = False
        break
for ele in seen2:
    if ele not in seen1:
        is_subset2 = False
        break
if is_subset1 or is_subset2:
    print('Array is a subset of another array')
else:
    print('Array is a not subset of another array')
