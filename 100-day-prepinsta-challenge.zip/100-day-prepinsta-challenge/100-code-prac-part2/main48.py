# Finding equilibrium index of an array
# equilibrium index : left_sum == right_sum 
# if equilibrium index exist return it else return -1

arr = [int(x) for x in input().split()]

def find_equi_index(arr):
    curr_sum, prefix = 0, []
    for ele in arr:
        curr_sum += ele
        prefix.append(curr_sum)
    
    for i in range(1,len(prefix) -1):
        if prefix[i - 1] == prefix[-1] - prefix[i]:
            return i
    return -1

print(f'Equilibrium Index: {find_equi_index(arr)}')
