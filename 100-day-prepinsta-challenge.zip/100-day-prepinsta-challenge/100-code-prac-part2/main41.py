# Find maximum product sub-array in a given array 
# [1, -2, -3, 0, 7, -8, -2] ==> 112

arr = [int(x) for x in input().split()]
res , curr_max, curr_min = max(arr),1,1

for 
