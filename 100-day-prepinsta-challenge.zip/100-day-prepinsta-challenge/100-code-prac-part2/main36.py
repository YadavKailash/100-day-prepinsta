# Removing Duplicates elements from an array
arr = [int(x) for x in input().split()]
res , seen = [], set()

for ele in arr:
    if ele not in seen:
        res.append(ele)
        seen.add(ele)

print(res)